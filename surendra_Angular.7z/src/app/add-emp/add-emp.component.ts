import { Component, OnInit } from '@angular/core';  
import { FormBuilder, FormGroup, Validators } from "@angular/forms";  
import { EmployeeService } from '../service/employee.service';  
import { Router } from "@angular/router";  
import { Employee } from '../model/employee.model';
  
@Component({  
  selector: 'app-add-emp',  
  templateUrl: './add-emp.component.html',  
  styleUrls: ['./add-emp.component.css']  
})  
export class AddEmpComponent implements OnInit {  
  
  empformlabel: string = 'Add Employee';  
  empformbtn: string = 'Save';  
  employee : Employee;
  constructor( private router: Router, private empService: EmployeeService) {  
    this.employee=new Employee();
  }  
  

  
  ngOnInit() {  
  
  }  
  onSubmit(emp:Employee) {  
    console.log('Create fire'); 

    console.log(emp);
    this.empService.createUser(emp)  
      .subscribe(data => {  
        this.router.navigate(['list-emp']);  
      },  
      error => {  
        alert(error);  
      });  
  }  
 
}  