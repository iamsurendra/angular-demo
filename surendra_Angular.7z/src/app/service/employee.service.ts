import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { Employee } from '../model/employee.model';
import { Observable } from 'rxjs';


  
@Injectable({  
  providedIn: 'root'  
})  
export class EmployeeService {  

oblist:Observable<Employee[]>;
emplist:Employee[];
  
  constructor(private http: HttpClient) { }  
  baseUrl: string = 'http://localhost:3000/emp-list';  
  
  getEmployees() {  
    this.oblist = this.http.get<Employee[]>(this.baseUrl);
    
    this.oblist.subscribe((data: Employee[]) => {  
      this.emplist = data;  
    }); 
    return this.oblist;
  }  
  deleteEmployees(deletee:Employee) { 
  
    for(var i = 1; i <= this.emplist.length; i++){
      console.log(this.emplist[i])
      console.log(deletee)

      if(this.emplist[i]==deletee){

      this.emplist.slice(i,1);}


   }
    //return this.http.delete<Employee[]>(this.baseUrl);  
  }  
  createUser(employee: Employee) {  
    return this.http.post(this.baseUrl, employee);  
  }  
  getEmployeeById(id: number) {  
    return this.http.get<Employee>(this.baseUrl + '/' + id);  
  }  
  updateEmployee(employee: Employee) {  
    return this.http.put(this.baseUrl + '/' + employee.id, employee);  
  }  
}