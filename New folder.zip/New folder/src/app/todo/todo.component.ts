import { Component, OnInit } from '@angular/core';
import { TodoService } from './todo.service';
import { ITodo } from './itodo';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {


  list: Array<ITodo> = [];

  constructor(private todoservice: TodoService) { }

  ngOnInit() {

    this.todoservice.getTodoList().subscribe((data) => { this.list = data; },(err) => console.log(err));

    this.todoservice.getBookList().subscribe((data) => console.log(data));
  }

  addTask(task:ITodo){
    this.todoservice.addTask(task).subscribe((data) => console.log(data));

  }

}
