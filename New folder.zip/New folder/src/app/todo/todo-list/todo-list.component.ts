import { Component, OnInit, OnChanges,EventEmitter,Input,Output,SimpleChanges } from '@angular/core';
import { ITodo } from '../itodo';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit,OnChanges {

  @Input() empDetail: ITodo;
  @Input() todoList: Array<ITodo>;
  @Output() selectdEmployee= new EventEmitter<ITodo>();

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void{
    console.log(changes);
  }

  ngOnInit() {
  }

  sendToParent(employee1: ITodo)
  {
    this.selectdEmployee.emit(employee1);
    console.log(employee1);
  }

}
