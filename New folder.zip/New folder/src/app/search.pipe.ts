import { Pipe, PipeTransform } from '@angular/core';
import { IEmployee } from './employee/iemployee';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(empList: Array<IEmployee>, serachText: string): Array<IEmployee> {
    return empList.filter((emp) => emp.name.toLowerCase().includes(serachText.toLowerCase()));
  }

}
