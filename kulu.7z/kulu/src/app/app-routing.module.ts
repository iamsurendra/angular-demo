import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { TodoComponent } from './todo/todo.component';
import { TodoDetailsComponent } from './todo/todo-details/todo-details.component';

const routes: Routes = [
{path: 'home',component: EmployeeComponent},
{path: 'todos',component:TodoComponent },
{path: 'todos/:id',component:TodoDetailsComponent },
{path: '',redirectTo:'home', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
