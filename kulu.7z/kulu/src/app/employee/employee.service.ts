import { Injectable } from '@angular/core';
import {IEmployee} from './iemployee'
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  list:Array<IEmployee> = [];

  constructor() { }

  getEmployeeList():Array<IEmployee>{
    return this.list=[
      {
        id:1,
        age:22,
        name:'Prem',
        dob: new Date('26-Feb-1997')
      },
      {
        id:2,
        age:101,
        name:'Adrika',
        dob : new Date('15-Jan-1997')
      },
      {
        id:3,
        age:102,
        name:'Kulakarini',
        dob: new Date('18-Dec-1994')
      }
    ];  }

    addEployee(){
      this.list.push(
    {
      age:44,
      id:4,
      name:"Suri",
       dob: new Date('26-Feb-1997')
      
    });
  }
}
