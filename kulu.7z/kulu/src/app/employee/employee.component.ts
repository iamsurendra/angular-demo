import { Component, OnInit,DoCheck ,Self} from '@angular/core';
import{IEmployee}from './iemployee'
import {EmployeeService} from './employee.service'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent implements OnInit,DoCheck {
  empName:string ="Prem";
  department="CSE";
  detail: IEmployee={
    age: 22,
    id: 1,
    name:'Prem',
    dob: new Date('26-Feb-1997')
  };

  list:Array<IEmployee> =  [] ;

  isValid=false;

  constructor(@Self() private empService: EmployeeService) { }

  ngOnInit() {

    this.list =this.empService.getEmployeeList();
  }

  ngDoCheck()
  {
    console.log('change event called');
  }

  toggle()
  {
    this.isValid =! this.isValid;
  }
  refresh()
  {
    this.list=[
      {
        id:1,
        age:22,
        name:'PremKumar',
        dob: new Date('26-Feb-1997')
      },
      {
        id:2,
        age:1201,
        name:'Adrika2',
        dob: new Date('26-Feb-1700')
      },
      {
        id:3,
        age:1002,
        name:'Kulakarini2',
        dob: new Date('26-Feb-1500')
      }

    ];

  }

  recieveFromChild(employee: IEmployee)
  {
    console.log(employee);
  }

}
