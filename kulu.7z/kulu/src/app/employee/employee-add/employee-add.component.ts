import { Component, OnInit } from '@angular/core';
import {IEmployee} from '../iemployee'

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  employee:IEmployee = {
    id:0,
    age:0,
    name:'',
    dob:new Date()
  }

  constructor() { }

  ngOnInit() {
  }
    addEmployee()
    {
      console.log(this.employee);
    }
  

}
