import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {ITodo} from './itodo';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

 bookAPI = '/assets/booklist.json'


  constructor(private http:HttpClient) { }

  getTodoList()
  {
    return this.http.get<ITodo[]>('https://jsonplaceholder.typicode.com/todos')
  }

  

  addTask(task:ITodo){
    return this.http.post<ITodo>('https://jsonplaceholder.typicode.com/todos',task);
  }

  getBookList(){
    return this.http.get(this.bookAPI)
  }
  }

