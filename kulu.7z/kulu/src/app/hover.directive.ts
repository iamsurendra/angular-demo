import { Directive, ElementRef,Renderer2,HostListener,Input} from '@angular/core';


@Directive({
  selector: '[appHover]'
})
export class HoverDirective {
  @Input() backColor='';
  constructor(private el: ElementRef,private render:Renderer2) { 

    console.log(el.nativeElement);
    
  }


@HostListener('mouseenter') onmouseenter()
{
  this.render.setStyle(this.el.nativeElement,'background-color',this.backColor);
}
@HostListener('mouseleave') onmouseleave()
{
  this.render.setStyle(this.el.nativeElement,'background-color','White')
}
}
