import { Component, OnInit } from '@angular/core';
import { TodoModel } from '../Model/TodoModel';
import { TodoService } from '../Service/todo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
todoArr:TodoModel[];
todo:TodoModel;
editable:boolean;
  constructor(private service:TodoService,private route:Router) {
    this.todoArr=[];
    this.todo=new TodoModel;
   }

  ngOnInit() {
    this.todoArr=this.service.display();
  }

  delete(index:number){

    this.service.delete(index);
  }


  edit(id:number){
    this.editable=true;
    this.service.set(id);
    this.route.navigate(['/edit']);

  }

}
