import { Component, OnInit } from '@angular/core';
import { UserModel } from '../model/UserModel';
import { UserServiceService } from '../service/user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  userList : UserModel[] = [];
 
  user:UserModel;
editable:boolean;
  constructor(private userService : UserServiceService, private router: Router) {  
    this.userList=[];
    this. user=new UserModel;
  }

  ngOnInit() {
    this.userList = this.userService.getList();
    this.userList=this.userService.display();
  }

  delete(index: number) {
    var ans = confirm("Are You Sure You want To delete?")
    if (ans) {
      this.userService.deleteUser(index); //delete from service
    }
  }


  edit(firstName:string){
    var ans = confirm("Are You Sure You want To Update?")
    if (ans) {
    this.editable=true;
    this.userService.set(firstName);
    //this.userService.deleteUser(index);
    this.userService.edit(firstName);
    

    this.router.navigate(['/edit']);
    }
  }
}
