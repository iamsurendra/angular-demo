import { Component, OnInit } from '@angular/core';
import{ FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from '../service/user-service.service';
import { UserModel } from '../model/UserModel';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  user : UserModel;
 
 
  editable:boolean;
  constructor(private userService : UserServiceService, private router: Router) { 
   
    this.user = new UserModel();
  }
  ngOnInit() {
    this.user=this.userService.edit(this.userService.get());
  
  }
  UpdateUser() {
    
    this.router.navigate(['/show']);
}
}
