import { Injectable } from '@angular/core';
import { UserModel } from '../model/UserModel';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  userList : UserModel[] = [];
//  // Array where we are going to do CRUD operations    
//  userModel: UserModel[] = new Array();    
    
//  // Other variables    
//  IsForUpdate: boolean = false;    
//  newUser: any = {};    
//  updatedUser;    
idedit:string;
   
  constructor() {}

  // // When user clicks on update button to submit updated value  
  // UpdateUser(_user: UserModel) {  
  //   let data = this.updatedUser;  
  //   for (let i = 0; i < this.userModel.length; i++) {  
  //     if (i == data) {  
  //       this.userModel[i] = this.newUser.Value;  
  //     }  
  //   }  
  //   this.IsForUpdate = false;  
  //   this.newUser = {};  
  // } 
  display(){
    return this.userList;
  }
  //add data in database
  insertUser(user: UserModel) {
    this.userList.push(user);
  }

  //return whole database
  getList(): UserModel[] {
    return this.userList;
  }

  //delete a entry
  deleteUser(firstName: number) {
    return this.userList.splice(firstName, firstName);
  }
  edit(firstName:string){
    var ans=confirm("are you sure you want to edit ?")
    if(ans){
      return this.userList.find(x=>x.firstName==firstName);
    }
   }
   set(firstName:string){
     this.idedit=firstName;
   }
   get(){
    return this.idedit;
   }


}
