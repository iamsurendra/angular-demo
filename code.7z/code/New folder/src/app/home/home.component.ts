import { Component, OnInit } from '@angular/core';
import { UserModel } from 'UserMgmt/src/app/model/UserModel';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userList : UserModel[] = [];
  constructor(private userService: UserServiceService) { }

  ngOnInit() {
    this.userList = this.userService.getList();
  }

}
